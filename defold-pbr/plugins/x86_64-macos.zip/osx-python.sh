#!/bin/bash
source "$HOME/.zprofile"
python "$@"
